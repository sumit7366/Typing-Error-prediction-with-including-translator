

import tkinter as tk
import random
from tkinter import messagebox
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.ensemble import RandomForestClassifier
from googletrans import Translator

class TypingTutor:
    def __init__(self, master):
        self.master = master
        self.master.title("Typing Tutor")

        self.current_word = ''
        self.should_change_word = True
        
        self.label_text = tk.StringVar()
        self.label_text.set("Type: " + self.current_word)
        self.label = tk.Label(master, textvariable=self.label_text, font=('Helvetica', 24))
        self.label.pack(pady=20)
        
        self.entry = tk.Entry(master, font=('Helvetica', 24))
        self.entry.pack(pady=10)
        self.entry.focus_set()
        self.entry.bind('<Return>', self.check_input)
        
        self.feedback_label = tk.Label(master, text="", font=('Helvetica', 18))
        self.feedback_label.pack(pady=10)
        
        self.incorrect_words = []
        
        self.create_keyboard()
        
        # Load and train the deep learning model
        self.vectorizer = CountVectorizer(analyzer='char', ngram_range=(2, 3))  # Character n-grams
        self.clf = RandomForestClassifier(n_estimators=100, random_state=42)
        self.train_model()

    def create_keyboard(self):
        self.keyboard_frame = tk.Frame(self.master)
        self.keyboard_frame.pack(pady=10)
        
        layout = [
            ['q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p'],
            ['a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l'],
            ['z', 'x', 'c', 'v', 'b', 'n', 'm'],
            ['Clipboard', 'Convert', 'Language', 'Settings']
        ]
        
        for row, row_letters in enumerate(layout):
            for col, key in enumerate(row_letters):
                button = tk.Button(self.keyboard_frame, text=key, font=('Helvetica', 12), width=8, command=lambda k=key: self.on_keyboard_click(k))
                button.grid(row=row, column=col, padx=5, pady=5)

    def on_keyboard_click(self, key):
        if key == 'Clipboard':
            self.clipboard_operation()
        elif key == 'Convert':
            self.convert_language()
        elif key == 'Language':
            self.change_language()
        elif key == 'Settings':
            self.open_settings()
        else:
            self.entry.insert(tk.END, key)

    def clipboard_operation(self):
        # Implement clipboard operations
        pass

    def convert_language(self):
        text_to_translate = self.current_word
        translator = Translator()
        translated_text = translator.translate(text_to_translate, dest='hi').text
        self.label_text.set("Type: " + translated_text)

    def change_language(self):
        # Implement changing interface language
        pass

    def open_settings(self):
        # Implement opening settings interface
        messagebox.showinfo("Settings", "Settings interface will be implemented here.")

    def train_model(self):
        # Sample data (replace this with your labeled dataset)
        words = ["hello", "helo", "world", "worlld", "test", "tets", "example", "exapmle"]
        labels = [0, 1, 0, 1, 0, 1, 0, 1]  # 0 for correct, 1 for typo
        
        X = self.vectorizer.fit_transform(words)
        self.clf.fit(X, labels)

    def predict_typo(self, word):
        word_vectorized = self.vectorizer.transform([word])
        prediction = self.clf.predict(word_vectorized)
        return prediction[0]

    def change_word(self):
        dataset = [("hello", 0), ("world", 0), ("test", 0), ("example", 0), ("helo", 1), ("worlld", 1), ("tets", 1), ("exapmle", 1)]
        word, _ = random.choice(dataset)
        self.current_word = word
        self.label_text.set("Type: " + self.current_word)

    def check_input(self, event):
        user_input = self.entry.get().strip().lower()
        prediction = self.predict_typo(user_input)
        
        if user_input == self.current_word:
            self.feedback_label.config(text="Correct!", fg="green")
            # Update your statistics or anything you need to do
        else:
            self.feedback_label.config(text="Incorrect. Try again.", fg="red")
            self.incorrect_words.append(self.current_word)
            self.should_change_word = False  # Set flag to prevent word change
        
        self.entry.delete(0, tk.END)
        
        if self.should_change_word:
            self.change_word()
        else:
            self.label_text.set("Type: " + self.current_word)  # Repeat the current word
        
        self.should_change_word = True  # Reset flag

def main():
    root = tk.Tk()
    typing_tutor = TypingTutor(master=root)
    typing_tutor.change_word()
    root.mainloop()

main()
